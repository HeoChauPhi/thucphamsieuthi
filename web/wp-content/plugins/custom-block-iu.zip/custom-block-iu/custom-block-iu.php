<?php
/**
 * Plugin Name: Custom blocks UI
 * Plugin URI: http://heochaua.com/
 * Description: Create custom blocks UI with ACF plugin
 * Version: 1.0
 * Author: HeoChauA
 * Author URI: http://heochaua.com/
 * License: GPLv2
 */

/*
 *
 * Add custom post type name Blocks UI
 *
 */
function custom_block_ui_create_custom_post_types() {
  // Hotel
  register_post_type( 'block_ui',
    array(
      'labels' => array(
        'name'               => _x( 'Blocks UI', 'post type general name', 'custom_block_ui' ),
        'singular_name'      => _x( 'Block UI', 'post type singular name', 'custom_block_ui' ),
        'menu_name'          => _x( 'Blocks UI', 'admin menu', 'custom_block_ui' ),
        'name_admin_bar'     => _x( 'Block UI', 'add new on admin bar', 'custom_block_ui' ),
        'add_new'            => _x( 'Add New', 'Block UI', 'custom_block_ui' ),
        'add_new_item'       => __( 'Add New Block UI', 'custom_block_ui' ),
        'new_item'           => __( 'New Block UI', 'custom_block_ui' ),
        'edit_item'          => __( 'Edit Block UI', 'custom_block_ui' ),
        'view_item'          => __( 'View Block UI', 'custom_block_ui' ),
        'all_items'          => __( 'All Blocks UI', 'custom_block_ui' ),
        'search_items'       => __( 'Search Blocks UI', 'custom_block_ui' ),
        'parent_item_colon'  => __( 'Parent Blocks UI:', 'custom_block_ui' ),
        'not_found'          => __( 'No Blocks UI found.', 'custom_block_ui' ),
        'not_found_in_trash' => __( 'No Blocks UI found in Trash.', 'custom_block_ui' )
      ),
      'description'           => __( 'Description.', 'custom_block_ui' ),
      'public'                => true,
      'publicly_queryable'    => true,
      'show_ui'               => true,
      'show_in_menu'          => true,
      'query_var'             => true,
      'rewrite'               => array('slug' => 'block_ui'),
      'has_archive'           => true,
      'hierarchical'          => false,
      'menu_position'         => 20,
      'supports'              => array( 'title', 'editor' ),
      'capability_type'       => 'post',
    )
  );
}
add_action( 'init', 'custom_block_ui_create_custom_post_types' );

/*register_activation_hook( __FILE__, 'custom_block_ui_activation_' );
function custom_block_ui_activation_() {
  add_action( 'init', 'custom_block_ui_create_custom_post_types' );
}*/

register_uninstall_hook( __FILE__, 'custom_block_ui_uninstall' );
function custom_block_ui_uninstall() {
  $args = array (
    'post_type' => 'block_ui',
    'posts_per_page' => -1
  );
  $query = new WP_Query ($args);
  while ($query->have_posts ()) {
    $query->the_post ();
    $id = get_the_ID ();
    wp_delete_post ($id, true);
  }
  wp_reset_postdata ();
}